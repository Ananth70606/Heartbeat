# Heartbeat Android Demo
A starter Android Studio project for the Heartbeat app.
Features: mobile-number screen, demo OTP screen, and home UI for Chat/Voice/Video/Profile.

Important: OTP verification is currently DEMO ONLY. Real SMS OTP requires a backend such as Firebase Authentication and proper project configuration. Voice/video calling also requires a real-time calling backend/service.
