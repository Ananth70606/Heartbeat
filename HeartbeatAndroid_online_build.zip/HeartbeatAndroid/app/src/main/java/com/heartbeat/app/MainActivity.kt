package com.heartbeat.app

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val red = Color.rgb(220, 45, 75)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }
    private fun showLogin() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(40,40,40,40)
        }
        val title = TextView(this).apply { text = "❤️ Heartbeat"; textSize = 32f; gravity=Gravity.CENTER; setTextColor(red) }
        val phone = EditText(this).apply { hint="Mobile number"; inputType=2 }
        val button = Button(this).apply { text="Send OTP" }
        box.addView(title); box.addView(phone, LinearLayout.LayoutParams(-1, -2))
        box.addView(button)
        button.setOnClickListener { showOtp(phone.text.toString()) }
        setContentView(box)
    }
    private fun showOtp(phone: String) {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(40,40,40,40) }
        val title = TextView(this).apply { text="Enter OTP"; textSize=28f; gravity=Gravity.CENTER; setTextColor(red) }
        val otp = EditText(this).apply { hint="6-digit OTP"; inputType=2; maxLines=1 }
        val verify = Button(this).apply { text="Verify" }
        box.addView(title); box.addView(otp); box.addView(verify)
        verify.setOnClickListener { showHome() }
        setContentView(box)
    }
    private fun showHome() {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(30,50,30,30) }
        val title = TextView(this).apply { text="❤️ Heartbeat"; textSize=30f; setTextColor(red) }
        box.addView(title)
        listOf("💬  Chat", "📞  Voice Call", "📹  Video Call", "👤  Profile").forEach {
            val b=Button(this).apply{text=it}
            box.addView(b, LinearLayout.LayoutParams(-1, -2))
        }
        setContentView(box)
    }
}
